Quickstart
==========

.. toctree::
    install
    training
..    inference